var 0001__initial_8py =
[
    [ "food.migrations.0001_initial.Migration", "classfood_1_1migrations_1_10001__initial_1_1_migration.html", null ]
];