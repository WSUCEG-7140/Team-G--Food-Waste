var 0002__agent__model_8py =
[
    [ "food.migrations.0002_agent_model.Migration", "classfood_1_1migrations_1_10002__agent__model_1_1_migration.html", null ]
];