var 0003__assign__model_8py =
[
    [ "food.migrations.0003_assign_model.Migration", "classfood_1_1migrations_1_10003__assign__model_1_1_migration.html", null ]
];