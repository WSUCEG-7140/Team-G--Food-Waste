var 0004__donarregister__model_8py =
[
    [ "food.migrations.0004_donarregister_model.Migration", "classfood_1_1migrations_1_10004__donarregister__model_1_1_migration.html", null ]
];