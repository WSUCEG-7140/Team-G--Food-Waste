var 0005__rename__username__donarregister__model__name_8py =
[
    [ "food.migrations.0005_rename_username_donarregister_model_name.Migration", "classfood_1_1migrations_1_10005__rename__username__donarregister__model__name_1_1_migration.html", null ]
];