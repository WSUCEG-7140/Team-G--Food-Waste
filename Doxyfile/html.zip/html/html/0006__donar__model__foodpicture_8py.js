var 0006__donar__model__foodpicture_8py =
[
    [ "food.migrations.0006_donar_model_foodpicture.Migration", "classfood_1_1migrations_1_10006__donar__model__foodpicture_1_1_migration.html", null ]
];