var 0008__auto__20230717__0556_8py =
[
    [ "food.migrations.0008_auto_20230717_0556.Migration", "classfood_1_1migrations_1_10008__auto__20230717__0556_1_1_migration.html", null ]
];