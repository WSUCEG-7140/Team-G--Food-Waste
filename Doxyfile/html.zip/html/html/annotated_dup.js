var annotated_dup =
[
    [ "food", "namespacefood.html", [
      [ "apps", "namespacefood_1_1apps.html", [
        [ "FoodConfig", "classfood_1_1apps_1_1_food_config.html", null ]
      ] ],
      [ "forms", "namespacefood_1_1forms.html", [
        [ "Agent_ModelCreate", "classfood_1_1forms_1_1_agent___model_create.html", "classfood_1_1forms_1_1_agent___model_create" ],
        [ "Assign_ModelCreate", "classfood_1_1forms_1_1_assign___model_create.html", "classfood_1_1forms_1_1_assign___model_create" ],
        [ "Complaint_ModelCreate", "classfood_1_1forms_1_1_complaint___model_create.html", "classfood_1_1forms_1_1_complaint___model_create" ],
        [ "Donar_ModelCreate", "classfood_1_1forms_1_1_donar___model_create.html", "classfood_1_1forms_1_1_donar___model_create" ],
        [ "DonarRegister_ModelCreate", "classfood_1_1forms_1_1_donar_register___model_create.html", "classfood_1_1forms_1_1_donar_register___model_create" ],
        [ "Meta", "classfood_1_1forms_1_1_meta.html", null ],
        [ "Rating_ModelCreate", "classfood_1_1forms_1_1_rating___model_create.html", null ],
        [ "Suggestion_ModelCreate", "classfood_1_1forms_1_1_suggestion___model_create.html", "classfood_1_1forms_1_1_suggestion___model_create" ]
      ] ],
      [ "migrations", "namespacefood_1_1migrations.html", [
        [ "0001_initial", "namespacefood_1_1migrations_1_10001__initial.html", [
          [ "Migration", "classfood_1_1migrations_1_10001__initial_1_1_migration.html", null ]
        ] ],
        [ "0002_agent_model", "namespacefood_1_1migrations_1_10002__agent__model.html", [
          [ "Migration", "classfood_1_1migrations_1_10002__agent__model_1_1_migration.html", null ]
        ] ],
        [ "0003_assign_model", "namespacefood_1_1migrations_1_10003__assign__model.html", [
          [ "Migration", "classfood_1_1migrations_1_10003__assign__model_1_1_migration.html", null ]
        ] ],
        [ "0004_donarregister_model", "namespacefood_1_1migrations_1_10004__donarregister__model.html", [
          [ "Migration", "classfood_1_1migrations_1_10004__donarregister__model_1_1_migration.html", null ]
        ] ],
        [ "0005_rename_username_donarregister_model_name", "namespacefood_1_1migrations_1_10005__rename__username__donarregister__model__name.html", [
          [ "Migration", "classfood_1_1migrations_1_10005__rename__username__donarregister__model__name_1_1_migration.html", null ]
        ] ],
        [ "0006_donar_model_foodpicture", "namespacefood_1_1migrations_1_10006__donar__model__foodpicture.html", [
          [ "Migration", "classfood_1_1migrations_1_10006__donar__model__foodpicture_1_1_migration.html", null ]
        ] ],
        [ "0007_complaint_model_rating_model_suggestion_model", "namespacefood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model.html", [
          [ "Migration", "classfood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model_1_1_migration.html", null ]
        ] ],
        [ "0008_auto_20230717_0556", "namespacefood_1_1migrations_1_10008__auto__20230717__0556.html", [
          [ "Migration", "classfood_1_1migrations_1_10008__auto__20230717__0556_1_1_migration.html", null ]
        ] ]
      ] ],
      [ "models", "namespacefood_1_1models.html", [
        [ "Agent_Model", "classfood_1_1models_1_1_agent___model.html", "classfood_1_1models_1_1_agent___model" ],
        [ "Assign_Model", "classfood_1_1models_1_1_assign___model.html", "classfood_1_1models_1_1_assign___model" ],
        [ "Complaint_Model", "classfood_1_1models_1_1_complaint___model.html", "classfood_1_1models_1_1_complaint___model" ],
        [ "Donar_Model", "classfood_1_1models_1_1_donar___model.html", "classfood_1_1models_1_1_donar___model" ],
        [ "DonarRegister_Model", "classfood_1_1models_1_1_donar_register___model.html", "classfood_1_1models_1_1_donar_register___model" ],
        [ "Rating_Model", "classfood_1_1models_1_1_rating___model.html", "classfood_1_1models_1_1_rating___model" ],
        [ "Suggestion_Model", "classfood_1_1models_1_1_suggestion___model.html", "classfood_1_1models_1_1_suggestion___model" ]
      ] ],
      [ "test", "namespacefood_1_1test.html", [
        [ "Complaint_ModelTest", "classfood_1_1test_1_1_complaint___model_test.html", "classfood_1_1test_1_1_complaint___model_test" ],
        [ "DonarRegister_ModelTest", "classfood_1_1test_1_1_donar_register___model_test.html", null ],
        [ "DonorPageViewTest", "classfood_1_1test_1_1_donor_page_view_test.html", "classfood_1_1test_1_1_donor_page_view_test" ],
        [ "Rating_ModelTest", "classfood_1_1test_1_1_rating___model_test.html", "classfood_1_1test_1_1_rating___model_test" ],
        [ "Suggestion_ModelTest", "classfood_1_1test_1_1_suggestion___model_test.html", "classfood_1_1test_1_1_suggestion___model_test" ]
      ] ]
    ] ]
];