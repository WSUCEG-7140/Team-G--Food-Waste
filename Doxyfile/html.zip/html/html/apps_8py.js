var apps_8py =
[
    [ "food.apps.FoodConfig", "classfood_1_1apps_1_1_food_config.html", null ]
];