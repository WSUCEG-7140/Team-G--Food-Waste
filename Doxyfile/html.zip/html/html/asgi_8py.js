var asgi_8py =
[
    [ "application", "asgi_8py.html#a28e7529971fae0c78c6622916e9f8b65", null ]
];