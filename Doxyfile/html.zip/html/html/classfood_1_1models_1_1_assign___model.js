var classfood_1_1models_1_1_assign___model =
[
    [ "__str__", "classfood_1_1models_1_1_assign___model.html#a72cc2b6f9fc98763ce24194a78e774c6", null ]
];