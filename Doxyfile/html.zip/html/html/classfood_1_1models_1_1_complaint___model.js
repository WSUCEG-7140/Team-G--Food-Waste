var classfood_1_1models_1_1_complaint___model =
[
    [ "__str__", "classfood_1_1models_1_1_complaint___model.html#ae80b1613b992830a6c1f7c32bf08c585", null ]
];