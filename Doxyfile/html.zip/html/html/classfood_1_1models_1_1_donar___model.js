var classfood_1_1models_1_1_donar___model =
[
    [ "__str__", "classfood_1_1models_1_1_donar___model.html#a01fe7301425d05b18100cc2c3ed4af52", null ]
];