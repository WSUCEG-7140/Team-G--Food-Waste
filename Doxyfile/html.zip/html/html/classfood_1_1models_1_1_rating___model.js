var classfood_1_1models_1_1_rating___model =
[
    [ "__str__", "classfood_1_1models_1_1_rating___model.html#a9fad4bdb36b4df427fd1cc15d92836ee", null ]
];