var classfood_1_1test_1_1_complaint___model_test =
[
    [ "setUp", "classfood_1_1test_1_1_complaint___model_test.html#a59eb06b8dc96ed0ff8d99d38be617c98", null ],
    [ "test_text_content", "classfood_1_1test_1_1_complaint___model_test.html#a9d37351be0120011c46e9e2e505a2947", null ]
];