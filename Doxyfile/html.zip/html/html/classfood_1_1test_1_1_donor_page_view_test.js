var classfood_1_1test_1_1_donor_page_view_test =
[
    [ "setUp", "classfood_1_1test_1_1_donor_page_view_test.html#a45da4877db59e4fa4190c0f1dce7c3e7", null ],
    [ "test_view_url_exits_at_proper_location", "classfood_1_1test_1_1_donor_page_view_test.html#afe72096a0e400684664f738a4fcf883f", null ]
];