var classfood_1_1test_1_1_rating___model_test =
[
    [ "setUp", "classfood_1_1test_1_1_rating___model_test.html#a703ed8c437b44322eccb9248742c13ca", null ],
    [ "test_text_content", "classfood_1_1test_1_1_rating___model_test.html#a8022021eab1bb2a884d72bb984601284", null ]
];