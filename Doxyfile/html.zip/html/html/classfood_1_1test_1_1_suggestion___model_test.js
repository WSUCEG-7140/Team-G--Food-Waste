var classfood_1_1test_1_1_suggestion___model_test =
[
    [ "setUp", "classfood_1_1test_1_1_suggestion___model_test.html#a9337e694a5809935b53fe06c394c9607", null ],
    [ "test_text_content", "classfood_1_1test_1_1_suggestion___model_test.html#a594d5e737dec273005c2a7c22604e10f", null ]
];