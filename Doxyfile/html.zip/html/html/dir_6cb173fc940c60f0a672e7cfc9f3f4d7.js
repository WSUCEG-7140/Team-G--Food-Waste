var dir_6cb173fc940c60f0a672e7cfc9f3f4d7 =
[
    [ "assets", "dir_ac6ef430a402961d2c9762f0f3c641eb.html", "dir_ac6ef430a402961d2c9762f0f3c641eb" ],
    [ "food", "dir_e2298f37d3c682cf671f5ad6229320c1.html", "dir_e2298f37d3c682cf671f5ad6229320c1" ],
    [ "foodwast", "dir_6fbf903cbe909077996dbb57eeb39074.html", "dir_6fbf903cbe909077996dbb57eeb39074" ],
    [ "manage.py", "manage_8py.html", "manage_8py" ]
];