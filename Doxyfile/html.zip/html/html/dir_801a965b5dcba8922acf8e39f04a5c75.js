var dir_801a965b5dcba8922acf8e39f04a5c75 =
[
    [ "0001_initial.py", "0001__initial_8py.html", "0001__initial_8py" ],
    [ "0002_agent_model.py", "0002__agent__model_8py.html", "0002__agent__model_8py" ],
    [ "0003_assign_model.py", "0003__assign__model_8py.html", "0003__assign__model_8py" ],
    [ "0004_donarregister_model.py", "0004__donarregister__model_8py.html", "0004__donarregister__model_8py" ],
    [ "0005_rename_username_donarregister_model_name.py", "0005__rename__username__donarregister__model__name_8py.html", "0005__rename__username__donarregister__model__name_8py" ],
    [ "0006_donar_model_foodpicture.py", "0006__donar__model__foodpicture_8py.html", "0006__donar__model__foodpicture_8py" ],
    [ "0007_complaint_model_rating_model_suggestion_model.py", "0007__complaint__model__rating__model__suggestion__model_8py.html", "0007__complaint__model__rating__model__suggestion__model_8py" ],
    [ "0008_auto_20230717_0556.py", "0008__auto__20230717__0556_8py.html", "0008__auto__20230717__0556_8py" ],
    [ "__init__.py", "food_2migrations_2____init_____8py.html", null ]
];