var dir_e2298f37d3c682cf671f5ad6229320c1 =
[
    [ "migrations", "dir_801a965b5dcba8922acf8e39f04a5c75.html", "dir_801a965b5dcba8922acf8e39f04a5c75" ],
    [ "__init__.py", "food_2____init_____8py.html", null ],
    [ "admin.py", "admin_8py.html", null ],
    [ "apps.py", "apps_8py.html", "apps_8py" ],
    [ "forms.py", "forms_8py.html", "forms_8py" ],
    [ "models.py", "models_8py.html", "models_8py" ],
    [ "test.py", "test_8py.html", "test_8py" ],
    [ "tests.py", "tests_8py.html", null ],
    [ "views.py", "views_8py.html", "views_8py" ]
];