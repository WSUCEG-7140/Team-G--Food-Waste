var forms_8py =
[
    [ "food.forms.Donar_ModelCreate", "classfood_1_1forms_1_1_donar___model_create.html", "classfood_1_1forms_1_1_donar___model_create" ],
    [ "food.forms.Donar_ModelCreate.Meta", "classfood_1_1forms_1_1_donar___model_create_1_1_meta.html", null ],
    [ "food.forms.Complaint_ModelCreate", "classfood_1_1forms_1_1_complaint___model_create.html", "classfood_1_1forms_1_1_complaint___model_create" ],
    [ "food.forms.Complaint_ModelCreate.Meta", "classfood_1_1forms_1_1_complaint___model_create_1_1_meta.html", null ],
    [ "food.forms.Suggestion_ModelCreate", "classfood_1_1forms_1_1_suggestion___model_create.html", "classfood_1_1forms_1_1_suggestion___model_create" ],
    [ "food.forms.Suggestion_ModelCreate.Meta", "classfood_1_1forms_1_1_suggestion___model_create_1_1_meta.html", null ],
    [ "food.forms.Rating_ModelCreate", "classfood_1_1forms_1_1_rating___model_create.html", null ],
    [ "food.forms.Meta", "classfood_1_1forms_1_1_meta.html", null ],
    [ "food.forms.DonarRegister_ModelCreate", "classfood_1_1forms_1_1_donar_register___model_create.html", "classfood_1_1forms_1_1_donar_register___model_create" ],
    [ "food.forms.DonarRegister_ModelCreate.Meta", "classfood_1_1forms_1_1_donar_register___model_create_1_1_meta.html", null ],
    [ "food.forms.Agent_ModelCreate", "classfood_1_1forms_1_1_agent___model_create.html", "classfood_1_1forms_1_1_agent___model_create" ],
    [ "food.forms.Agent_ModelCreate.Meta", "classfood_1_1forms_1_1_agent___model_create_1_1_meta.html", null ],
    [ "food.forms.Assign_ModelCreate", "classfood_1_1forms_1_1_assign___model_create.html", "classfood_1_1forms_1_1_assign___model_create" ],
    [ "food.forms.Assign_ModelCreate.Meta", "classfood_1_1forms_1_1_assign___model_create_1_1_meta.html", null ]
];