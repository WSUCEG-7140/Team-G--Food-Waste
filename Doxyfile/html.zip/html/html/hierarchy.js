var hierarchy =
[
    [ "food.forms.Agent_ModelCreate.Meta", "classfood_1_1forms_1_1_agent___model_create_1_1_meta.html", null ],
    [ "food.forms.Assign_ModelCreate.Meta", "classfood_1_1forms_1_1_assign___model_create_1_1_meta.html", null ],
    [ "food.forms.Complaint_ModelCreate.Meta", "classfood_1_1forms_1_1_complaint___model_create_1_1_meta.html", null ],
    [ "food.forms.Donar_ModelCreate.Meta", "classfood_1_1forms_1_1_donar___model_create_1_1_meta.html", null ],
    [ "food.forms.DonarRegister_ModelCreate.Meta", "classfood_1_1forms_1_1_donar_register___model_create_1_1_meta.html", null ],
    [ "food.forms.Meta", "classfood_1_1forms_1_1_meta.html", null ],
    [ "food.forms.Suggestion_ModelCreate.Meta", "classfood_1_1forms_1_1_suggestion___model_create_1_1_meta.html", null ],
    [ "migrations.Migration", null, [
      [ "food.migrations.0001_initial.Migration", "classfood_1_1migrations_1_10001__initial_1_1_migration.html", null ],
      [ "food.migrations.0002_agent_model.Migration", "classfood_1_1migrations_1_10002__agent__model_1_1_migration.html", null ],
      [ "food.migrations.0003_assign_model.Migration", "classfood_1_1migrations_1_10003__assign__model_1_1_migration.html", null ],
      [ "food.migrations.0004_donarregister_model.Migration", "classfood_1_1migrations_1_10004__donarregister__model_1_1_migration.html", null ],
      [ "food.migrations.0005_rename_username_donarregister_model_name.Migration", "classfood_1_1migrations_1_10005__rename__username__donarregister__model__name_1_1_migration.html", null ],
      [ "food.migrations.0006_donar_model_foodpicture.Migration", "classfood_1_1migrations_1_10006__donar__model__foodpicture_1_1_migration.html", null ],
      [ "food.migrations.0007_complaint_model_rating_model_suggestion_model.Migration", "classfood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model_1_1_migration.html", null ],
      [ "food.migrations.0008_auto_20230717_0556.Migration", "classfood_1_1migrations_1_10008__auto__20230717__0556_1_1_migration.html", null ]
    ] ],
    [ "models.Model", null, [
      [ "food.models.Agent_Model", "classfood_1_1models_1_1_agent___model.html", null ],
      [ "food.models.Assign_Model", "classfood_1_1models_1_1_assign___model.html", null ],
      [ "food.models.Complaint_Model", "classfood_1_1models_1_1_complaint___model.html", null ],
      [ "food.models.DonarRegister_Model", "classfood_1_1models_1_1_donar_register___model.html", null ],
      [ "food.models.Donar_Model", "classfood_1_1models_1_1_donar___model.html", null ],
      [ "food.models.Rating_Model", "classfood_1_1models_1_1_rating___model.html", null ],
      [ "food.models.Suggestion_Model", "classfood_1_1models_1_1_suggestion___model.html", null ]
    ] ],
    [ "forms.ModelForm", null, [
      [ "food.forms.Agent_ModelCreate", "classfood_1_1forms_1_1_agent___model_create.html", null ],
      [ "food.forms.Assign_ModelCreate", "classfood_1_1forms_1_1_assign___model_create.html", null ],
      [ "food.forms.Complaint_ModelCreate", "classfood_1_1forms_1_1_complaint___model_create.html", null ],
      [ "food.forms.DonarRegister_ModelCreate", "classfood_1_1forms_1_1_donar_register___model_create.html", null ],
      [ "food.forms.Donar_ModelCreate", "classfood_1_1forms_1_1_donar___model_create.html", null ],
      [ "food.forms.Rating_ModelCreate", "classfood_1_1forms_1_1_rating___model_create.html", null ],
      [ "food.forms.Suggestion_ModelCreate", "classfood_1_1forms_1_1_suggestion___model_create.html", null ]
    ] ],
    [ "AppConfig", null, [
      [ "food.apps.FoodConfig", "classfood_1_1apps_1_1_food_config.html", null ]
    ] ],
    [ "TestCase", null, [
      [ "food.test.Complaint_ModelTest", "classfood_1_1test_1_1_complaint___model_test.html", null ],
      [ "food.test.DonarRegister_ModelTest", "classfood_1_1test_1_1_donar_register___model_test.html", null ],
      [ "food.test.DonorPageViewTest", "classfood_1_1test_1_1_donor_page_view_test.html", null ],
      [ "food.test.Rating_ModelTest", "classfood_1_1test_1_1_rating___model_test.html", null ],
      [ "food.test.Suggestion_ModelTest", "classfood_1_1test_1_1_suggestion___model_test.html", null ]
    ] ]
];