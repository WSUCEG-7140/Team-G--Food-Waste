var manage_8py =
[
    [ "main", "manage_8py.html#a0ac64ea81648f42d6a49d76da894eaf4", null ]
];