var models_8py =
[
    [ "food.models.Donar_Model", "classfood_1_1models_1_1_donar___model.html", "classfood_1_1models_1_1_donar___model" ],
    [ "food.models.DonarRegister_Model", "classfood_1_1models_1_1_donar_register___model.html", "classfood_1_1models_1_1_donar_register___model" ],
    [ "food.models.Agent_Model", "classfood_1_1models_1_1_agent___model.html", "classfood_1_1models_1_1_agent___model" ],
    [ "food.models.Assign_Model", "classfood_1_1models_1_1_assign___model.html", "classfood_1_1models_1_1_assign___model" ],
    [ "food.models.Complaint_Model", "classfood_1_1models_1_1_complaint___model.html", "classfood_1_1models_1_1_complaint___model" ],
    [ "food.models.Suggestion_Model", "classfood_1_1models_1_1_suggestion___model.html", "classfood_1_1models_1_1_suggestion___model" ],
    [ "food.models.Rating_Model", "classfood_1_1models_1_1_rating___model.html", "classfood_1_1models_1_1_rating___model" ]
];