var namespacefood_1_1migrations =
[
    [ "0001_initial", "namespacefood_1_1migrations_1_10001__initial.html", "namespacefood_1_1migrations_1_10001__initial" ],
    [ "0002_agent_model", "namespacefood_1_1migrations_1_10002__agent__model.html", "namespacefood_1_1migrations_1_10002__agent__model" ],
    [ "0003_assign_model", "namespacefood_1_1migrations_1_10003__assign__model.html", "namespacefood_1_1migrations_1_10003__assign__model" ],
    [ "0004_donarregister_model", "namespacefood_1_1migrations_1_10004__donarregister__model.html", "namespacefood_1_1migrations_1_10004__donarregister__model" ],
    [ "0005_rename_username_donarregister_model_name", "namespacefood_1_1migrations_1_10005__rename__username__donarregister__model__name.html", "namespacefood_1_1migrations_1_10005__rename__username__donarregister__model__name" ],
    [ "0006_donar_model_foodpicture", "namespacefood_1_1migrations_1_10006__donar__model__foodpicture.html", "namespacefood_1_1migrations_1_10006__donar__model__foodpicture" ],
    [ "0007_complaint_model_rating_model_suggestion_model", "namespacefood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model.html", "namespacefood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model" ],
    [ "0008_auto_20230717_0556", "namespacefood_1_1migrations_1_10008__auto__20230717__0556.html", "namespacefood_1_1migrations_1_10008__auto__20230717__0556" ]
];