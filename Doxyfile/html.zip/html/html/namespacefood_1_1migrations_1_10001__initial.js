var namespacefood_1_1migrations_1_10001__initial =
[
    [ "Migration", "classfood_1_1migrations_1_10001__initial_1_1_migration.html", null ]
];