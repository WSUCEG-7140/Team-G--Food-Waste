var namespacefood_1_1migrations_1_10003__assign__model =
[
    [ "Migration", "classfood_1_1migrations_1_10003__assign__model_1_1_migration.html", null ]
];