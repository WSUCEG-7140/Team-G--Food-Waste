var namespacefood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model =
[
    [ "Migration", "classfood_1_1migrations_1_10007__complaint__model__rating__model__suggestion__model_1_1_migration.html", null ]
];