var namespacefood_1_1migrations_1_10008__auto__20230717__0556 =
[
    [ "Migration", "classfood_1_1migrations_1_10008__auto__20230717__0556_1_1_migration.html", null ]
];