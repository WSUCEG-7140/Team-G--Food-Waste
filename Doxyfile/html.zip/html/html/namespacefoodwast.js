var namespacefoodwast =
[
    [ "asgi", "namespacefoodwast_1_1asgi.html", [
      [ "application", "namespacefoodwast_1_1asgi.html#a28e7529971fae0c78c6622916e9f8b65", null ]
    ] ],
    [ "settings", "namespacefoodwast_1_1settings.html", [
      [ "ALLOWED_HOSTS", "namespacefoodwast_1_1settings.html#a1cdbb1cb6dc0c197e843de58837105f6", null ],
      [ "AUTH_PASSWORD_VALIDATORS", "namespacefoodwast_1_1settings.html#a3231b4a698a7e9231b9db78f33b7b4c4", null ],
      [ "BASE_DIR", "namespacefoodwast_1_1settings.html#a7253dfc20091aaf28d987712482d0406", null ],
      [ "DATABASES", "namespacefoodwast_1_1settings.html#af7ef3f0900d9c737c9fa3bce8bb55fef", null ],
      [ "DEBUG", "namespacefoodwast_1_1settings.html#a604a85fa7a337b2d064ad2ddaf4995bc", null ],
      [ "INSTALLED_APPS", "namespacefoodwast_1_1settings.html#a05eb7192d664f3bdb6d5439c78dc7207", null ],
      [ "LANGUAGE_CODE", "namespacefoodwast_1_1settings.html#a411980678919cc8186664501462630c9", null ],
      [ "MEDIA_ROOT", "namespacefoodwast_1_1settings.html#a644a36d73797abe3df6132254843802e", null ],
      [ "MEDIA_URL", "namespacefoodwast_1_1settings.html#a1645fcc621009b013a385014a24e1886", null ],
      [ "MIDDLEWARE", "namespacefoodwast_1_1settings.html#a1701583b807d54bec8614ea82fd67b34", null ],
      [ "ROOT_URLCONF", "namespacefoodwast_1_1settings.html#a9f75ad1d1541e1a1cb89e3d7739b486b", null ],
      [ "SECRET_KEY", "namespacefoodwast_1_1settings.html#ae45f49594f0c952f3ef3b901020ea93a", null ],
      [ "STATIC_ROOT", "namespacefoodwast_1_1settings.html#a79f2aea6c8a0721dde0e3283fffd6046", null ],
      [ "STATIC_URL", "namespacefoodwast_1_1settings.html#ab541dd7e2edb836fa98c038ed1157c72", null ],
      [ "STATICFILES_DIRS", "namespacefoodwast_1_1settings.html#a291407e115bf9bbd5e67eeab190cb3ef", null ],
      [ "TEMPLATES", "namespacefoodwast_1_1settings.html#a65b663919a71653118217d12d84e4814", null ],
      [ "TIME_ZONE", "namespacefoodwast_1_1settings.html#a6b2f07f7308c4650a5d2cb7dda302a1c", null ],
      [ "USE_I18N", "namespacefoodwast_1_1settings.html#aa0318c451fe57e7fb02b48b45e946387", null ],
      [ "USE_L10N", "namespacefoodwast_1_1settings.html#a1bde396448067f035fb9e3fe45cbc52a", null ],
      [ "USE_TZ", "namespacefoodwast_1_1settings.html#adc9e62087f983f50a5731ae91c94c5ef", null ],
      [ "WSGI_APPLICATION", "namespacefoodwast_1_1settings.html#ad85f774b22901b76adb59016a19d352a", null ]
    ] ],
    [ "urls", "namespacefoodwast_1_1urls.html", [
      [ "document_root", "namespacefoodwast_1_1urls.html#ae8886552c2f976a21bfa19715b8e9fc8", null ],
      [ "MEDIA_URL", "namespacefoodwast_1_1urls.html#aca0ab8e79865748758658c545726c6cb", null ],
      [ "STATIC_URL", "namespacefoodwast_1_1urls.html#a44ae38d04a4b549894cf9b302c2558c3", null ],
      [ "urlpatterns", "namespacefoodwast_1_1urls.html#a06349baffed59c1fe726772cc971f03c", null ]
    ] ],
    [ "wsgi", "namespacefoodwast_1_1wsgi.html", [
      [ "application", "namespacefoodwast_1_1wsgi.html#aa22a0b8be160d417013e6fb68b5e41eb", null ]
    ] ]
];