var namespaces_dup =
[
    [ "food", "namespacefood.html", "namespacefood" ],
    [ "foodwast", "namespacefoodwast.html", "namespacefoodwast" ],
    [ "manage", "namespacemanage.html", [
      [ "main", "namespacemanage.html#a0ac64ea81648f42d6a49d76da894eaf4", null ]
    ] ]
];