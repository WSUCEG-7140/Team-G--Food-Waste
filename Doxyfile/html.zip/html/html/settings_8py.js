var settings_8py =
[
    [ "ALLOWED_HOSTS", "settings_8py.html#a1cdbb1cb6dc0c197e843de58837105f6", null ],
    [ "AUTH_PASSWORD_VALIDATORS", "settings_8py.html#a3231b4a698a7e9231b9db78f33b7b4c4", null ],
    [ "BASE_DIR", "settings_8py.html#a7253dfc20091aaf28d987712482d0406", null ],
    [ "DATABASES", "settings_8py.html#af7ef3f0900d9c737c9fa3bce8bb55fef", null ],
    [ "DEBUG", "settings_8py.html#a604a85fa7a337b2d064ad2ddaf4995bc", null ],
    [ "INSTALLED_APPS", "settings_8py.html#a05eb7192d664f3bdb6d5439c78dc7207", null ],
    [ "LANGUAGE_CODE", "settings_8py.html#a411980678919cc8186664501462630c9", null ],
    [ "MEDIA_ROOT", "settings_8py.html#a644a36d73797abe3df6132254843802e", null ],
    [ "MEDIA_URL", "settings_8py.html#a1645fcc621009b013a385014a24e1886", null ],
    [ "MIDDLEWARE", "settings_8py.html#a1701583b807d54bec8614ea82fd67b34", null ],
    [ "ROOT_URLCONF", "settings_8py.html#a9f75ad1d1541e1a1cb89e3d7739b486b", null ],
    [ "SECRET_KEY", "settings_8py.html#ae45f49594f0c952f3ef3b901020ea93a", null ],
    [ "STATIC_ROOT", "settings_8py.html#a79f2aea6c8a0721dde0e3283fffd6046", null ],
    [ "STATIC_URL", "settings_8py.html#ab541dd7e2edb836fa98c038ed1157c72", null ],
    [ "STATICFILES_DIRS", "settings_8py.html#a291407e115bf9bbd5e67eeab190cb3ef", null ],
    [ "TEMPLATES", "settings_8py.html#a65b663919a71653118217d12d84e4814", null ],
    [ "TIME_ZONE", "settings_8py.html#a6b2f07f7308c4650a5d2cb7dda302a1c", null ],
    [ "USE_I18N", "settings_8py.html#aa0318c451fe57e7fb02b48b45e946387", null ],
    [ "USE_L10N", "settings_8py.html#a1bde396448067f035fb9e3fe45cbc52a", null ],
    [ "USE_TZ", "settings_8py.html#adc9e62087f983f50a5731ae91c94c5ef", null ],
    [ "WSGI_APPLICATION", "settings_8py.html#ad85f774b22901b76adb59016a19d352a", null ]
];