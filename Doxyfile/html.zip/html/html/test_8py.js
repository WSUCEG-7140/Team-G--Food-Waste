var test_8py =
[
    [ "food.test.DonarRegister_ModelTest", "classfood_1_1test_1_1_donar_register___model_test.html", null ],
    [ "food.test.DonorPageViewTest", "classfood_1_1test_1_1_donor_page_view_test.html", "classfood_1_1test_1_1_donor_page_view_test" ],
    [ "food.test.Complaint_ModelTest", "classfood_1_1test_1_1_complaint___model_test.html", "classfood_1_1test_1_1_complaint___model_test" ],
    [ "food.test.Suggestion_ModelTest", "classfood_1_1test_1_1_suggestion___model_test.html", "classfood_1_1test_1_1_suggestion___model_test" ],
    [ "food.test.Rating_ModelTest", "classfood_1_1test_1_1_rating___model_test.html", "classfood_1_1test_1_1_rating___model_test" ],
    [ "setUp", "test_8py.html#af623fa211f6161040e8d0aefd661a2e9", null ],
    [ "test_text_content", "test_8py.html#a51e5ea93454c0316b02b93476b82ced5", null ]
];