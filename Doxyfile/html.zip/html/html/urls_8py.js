var urls_8py =
[
    [ "document_root", "urls_8py.html#ae8886552c2f976a21bfa19715b8e9fc8", null ],
    [ "MEDIA_URL", "urls_8py.html#aca0ab8e79865748758658c545726c6cb", null ],
    [ "STATIC_URL", "urls_8py.html#a44ae38d04a4b549894cf9b302c2558c3", null ],
    [ "urlpatterns", "urls_8py.html#a06349baffed59c1fe726772cc971f03c", null ]
];