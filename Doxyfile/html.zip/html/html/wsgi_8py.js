var wsgi_8py =
[
    [ "application", "wsgi_8py.html#aa22a0b8be160d417013e6fb68b5e41eb", null ]
];