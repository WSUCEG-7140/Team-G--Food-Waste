# Importing the TestCase class from Django's testing module.
from django.test import TestCase
